<?php 
require('../config/fonctions.php');
if (isset($_POST['pid'])) {
	$format = selectFormat($_POST['pid']);
}



 ?>