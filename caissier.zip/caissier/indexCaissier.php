<!doctype HTML>
<html>
    <title>Caisier </title>
    <head>
        <link href="/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
    </head>
    <body  style="background: gray">
        <div class="bg-success">
           
            <div class="container" style="margin-top: 0px;">
                <center>
              <button type="button" class="btn btn-default">Accueil</button>
              <button type="button" class="btn btn-primary">Produits</button>
              <button type="button" class="btn btn-client">Clients</button>
              <button type="button" class="btn btn-fournisseur">Ventre</button>
              <button type="button" class="btn btn-facture">Ventes</button>
              <button type="button" class="btn btn-accueil">Rapports</button>
               <button type="button" class="btn btn-inventaire">Dettes</button>
               
        </center>
        </div>
        </div>
    
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery-3.4.0.min.js"></script>
        
        
            
        
    </body>

</html>