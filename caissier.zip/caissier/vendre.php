<?php 
require ('../../config/fonctions.php');
global $idcommande, $montant;
$idcashbox = 5;
$clients = selectAllClients();

if (isset($_POST['search'])) 
{
	extract($_POST);
	$article_name = strip_tags($article_name);
	$details_article = searchProduct($article_name);
}
//creation du pannier
if (isset($_POST['neworder'])) 
{
	extract($_POST);
	$idcommande = createCommand($idcashbox, $client);
}

if (isset($_POST['add']))
	{
		extract($_POST);
		$id = strip_tags($id);
		$quantite = strip_tags($quantite);
		$add = addToPanner($id, $quantite);
		$rows = pannerContent($idcashbox);
		echo "Produit enregistré dans le pannier<br>";
	}
//suppression dun produit du contenu de la commande
if (isset($_GET['ID'])) 
{
	$rem = removeProductFromPanner($_GET['ID'], $_GET['QTY']);
	$rows = pannerContent($idcashbox);

}
//enregistrement de la commande
if (isset($_POST['save']))
{
	$comm = defOrder($idcashbox, $_POST['type'], $_POST['amount']);
	header('Location: ../config/pdf.php');
}

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <style type="text/css">
 	td input
 	{
 		border: 0px;
 		background: transparent;
 	}
 </style>
 <body>

 ///////////////////////////////////////////////////////
 <form action="#" method="post">
 	<h2>INFORMATIONS CLIENT</h2>
	 <select name="client" required>
	 	<option>client</option>
 		<?php foreach ($clients as $client): ?>
 			<option  value="<?= $client->ID_CLIENT?>"><?= $client->NAME.' '.$client->LASTNAME?></option>
 		<?php endforeach; ?>
 	</select>
 	<button name="neworder">NOUVELLE COMMANDE</button>
 </form>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
<form action="#" method="post">
 	<input type="search" name="article_name">
 	<button name="search">Rechercher</button>
 </form>
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
<?php if (isset($details_article) AND !empty($details_article)) { ?>
<h2>PERSONNALISATION DU PRODUIT DE LA COMMANDE</h2>
<form action="#" method="post">
	<table>
		<th>
			<tr>
				<td>ID</td>
				<td>TYPE</td>
				<td>PRODUIT</td>
				<td>FORMAT</td>
				<td>QUANTITE</td>
				<td>PRICE</td>
			</tr>
		</th>
	<?php } ?>
 	<?php if (isset($details_article) AND !empty($details_article)) {
 		foreach (array($details_article) as $details_article): ?>
 			<tr>
 			<td><input type="text" name="id" value="<?= $details_article['ID_PRODUCT']?>" readonly></td>
 			<td><input type="text" name="type" value="<?= $details_article['NAME']?>" required readonly></td>
 			<td><input type="text" name="product" value="<?= $details_article['PRODUCT_NAME']?>" required readonly></td>
 			<td><input type="text" name="format" value="<?= $details_article['FORMAT']?>"></td>
 			<td><input type="number" name="quantite" max="<?= $details_article['QUANTITY']?>" min=1 value="<?= $details_article['QUANTITY']?>" required ></td>
 			<td><input type="text" name="price" value="<?= $details_article['PRICE']?>" required readonly></td>
 			</tr>

 	<?php endforeach;
 		echo '<button name="add">Ajouter</button>';
 	 } ?>
 	 </table>
 </form>


//////////////////////////////////////////////////////////////////
<?php if(isset($rows) AND !empty($rows)){ $montant = 0; foreach ($rows as $row): ?>
 <h2>Produits disponibles</h2>
 <form action="#" method = "post">
 <table>
 	<thead>
 		<td>ID</td>
 		<td>NOM</td>
 		<td>FORMAT</td>
 		<td>PRIX</td>
 		<td>TAUX DE REDUCTION</td>
 		<td>EXPIRATION</td>
 		<td>QUANTITE</td>
 		<td>TYPE</td>
 		<td>SUPPRIMER</td>
 	</thead>
 		<tr>
 		<td><input type="text" name="id" readonly required value="<?= $row->ID_PRODUCT?>"></td>
 		<td><input type="text" name="product" readonly required value="<?= $row->PRODUCT_NAME?>"></td>
 		<td><input type="text" name="format" readonly required value="<?= $row->FORMAT?>"></td>
 		<td><input type="text" name="price" readonly required value="<?= $row->PRICE?>"></td>
 		<td><input type="text" name="reduction" readonly required value="<?= $row->REDUCTION_RATE?>"></td>
 		<td><input type="text" name="expiration" readonly required value="<?= $row->EXPIRATION?>"></td>
 		<td><input type="text" name="quantity" readonly required value="<?= $row->QUANTITY?>" min=1 max="$details_article"></td>
 		<td><input type="text" name="type" readonly required value="<?= $row->NAME?>"></td>
 		<td><a href="vendre10.php?ID=<?=$row->ID_PRODUCT?>&amp;QTY=<?= $row->QUANTITY?>">Supprimer</a></td>
 		</tr>
 	<?php $montant +=$row->QUANTITY*$row->PRICE*(1-$row->REDUCTION_RATE/100); endforeach; } ?>
 </table>
 	<fieldset>
 		<input type="text" value="<?= $montant?>">
 		<input type="text" name="amount" placeholder="Montant paye" required>
 		<select required name="type">
 			<option>Type de paiement</option>
 			<option value="Cash">Cash</option>
 			<option value="Mobile Money">Mobile Money</option>
 		</select>
 	</fieldset>
 	<button name='save'>ENREGISTRER</button>
 </form>
 
 

</body>
<?php include '../../footer.php'; ?>
</html>